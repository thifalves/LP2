﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        Double altura, raio, volume;

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textAltura.Text = "";
            textRaio.Text = String.Empty;
            textVolume.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textRaio.Text, out raio)
                || (raio == 0))
            {
                MessageBox.Show("Raio inválido");
                textRaio.Focus();
            }
            else if (!Double.TryParse(textAltura.Text, out altura)
                || (altura == 0))
            {
                MessageBox.Show("Altura Inválida");
                textAltura.Focus();
            }

            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                textVolume.Text = volume.ToString("N2");
            }
        }
                public Form1()
                {
                    InitializeComponent();
                }

        private void textRaio_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textRaio.Text, out raio)
                ||(raio <= 0)){
                MessageBox.Show("raio inválido");
            }
        }
    }
}
